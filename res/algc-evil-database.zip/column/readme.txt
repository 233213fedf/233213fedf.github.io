_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
_/_/_/_/_/_/_/ ＡｎｔｉＧＣ　Ｔｅａｍ _/_/_/_/_/_/_/
_/_/_/２３３２１３ｆｅｄｆ．ｇｉｔｈｕｂ．ｉｏ_/_/_/
_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
					   2019.3.23
            　 ＡＬＧＣ－Ｃｈｉｎｅｓｅ
 Evil_Zixue.png ........................ Zixue Tishi
 Evil_Gonggu.png .................... Gonggu Yunyong
 Evil_Tuozhan.png .................... Tuozhan Yuedu
 Evil_Huodong.png .................... Yuwen Huodong

　　　　　　　　　ＡＬＧＣ－Ｍａｔｈ
			      [_F is larger version]
 EvilJiChuYuan.png 
 EvilJiChuyuan_F.png .................... Jichu Xuan
 EvilZhiQuYuan.png 
 EvilZhiQuYuan_F.png .................... Zhiqu Xuan
 EvilTanSuoYuan.png 
 EvilTanSuoYuan_F.png .................. Tansuo Xuan 

　　　　　　　ＡＬＧＣ－Ｓｃｉｅｎｃｅ　
［Ｉｔ＇ｓ　ＥＶＶＶＩＩＩＩＬＬＬＬＬＬＬ！！！！！］
 Evil++_GuanchayuSikao.png ........ GuANcHa yU SiKaO
 Evil++_TanjiuYuTiyan.png .......... TaNjIU Yu TIYaN

----------------------------------------------------

            　          语 文
 Evil_Zixue.png …………………………………  自学提示
 Evil_Gonggu.png ………………………………… 巩固运用
 Evil_Tuozhan.png ………………………………  拓展阅读
 Evil_Huodong.png ………………………………  语文活动

　　　　　　　　      　数 学
 * _F 为大图
 EvilJiChuYuan.png 
 EvilJiChuyuan_F.png ……………………………… 基础园
 EvilZhiQuYuan.png 
 EvilZhiQuYuan_F.png ……………… 智取（划掉）智趣园
 EvilTanSuoYuan.png 
 EvilTanSuoYuan_F.png ……………………………  探索园

　　　　　　　          科 学　
［Ｉｔ＇ｓ　ＥＶＶＶＩＩＩＩＬＬＬＬＬＬＬ！！！！！］
 Evil++_GuanchayuSikao.png ………………… 观察与思考
 Evil++_TanjiuYuTiyan.png …………………  探究与体验